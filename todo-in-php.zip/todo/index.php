<!DOCTYPE html>
<html lang="en">
	<head>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
		<meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1"/>
	</head>
<body>
	<div class="col-md-3"></div>
	<div class="col-md-6 well">
		<h3 class="text-primary">TODO List</h3>
		<hr style="border-top:1px dotted #ccc;"/>
		<div class="col-md-2"></div>
		<div class="col-md-8">
			<center>
				<form method="POST" class="form-inline" action="add_query.php">
					<input type="text" class="form-control" name="list" required/>
					<button class="btn btn-primary form-control" name="add">Add Task</button>
				</form>
			</center>
		</div>
		<div class="col-md-8 list-task">
			<a title="All Tasks" href="index.php?status=All" class="btn btn-success">All Tasks</a>
			<a title="Completed Tasks" href="index.php?status=1" class="btn btn-warning">Completed Tasks</a>
			<a title="Pending Tasks" href="index.php?status=0" class="btn btn-danger">Pending Tasks</a>	
		</div>
		<table class="table table-bordered">
			<thead>
				<tr>
					<th>#</th>
					<th>Task</th>
					<th>Status</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<?php
					require 'dbconnect.php';
					if($_SERVER['QUERY_STRING']==''){
						$status="";
					}	
					else {
						$status=$_GET['status'];
					}				
					//$status=$_GET['status'];
					if($status==0){
						$query = $conn->query("SELECT * FROM `todo_list` where status=0 ORDER BY `list_id` ASC");
					}
					else if($status==1){
						$query = $conn->query("SELECT * FROM `todo_list` where status=1 ORDER BY `list_id` ASC");
					} else {
						$query = $conn->query("SELECT * FROM `todo_list` ORDER BY `list_id` ASC");
					}
						$count = 1;
						while($fetch = $query->fetch_array()){
				?>
				<tr>
					<td><?php echo $count++?></td>
					<td><?php echo $fetch['list']?></td>
					<td>
						<?php
							if($fetch['status'] == "1") 
								echo "Completed";
							else 
								echo "Pending";
						?>
					</td>
					<td colspan="2">
						<?php
								if($fetch['status'] != "1"){
									echo 
									'<a title="Mark Completed" href="update_task.php?list_id='.$fetch['list_id'].'" class="btn btn-success"><span class="glyphicon glyphicon-check"></span></a>';
								}
								else {
									echo 
									'<a title="Mark Pending" href="update_task.php?list_id='.$fetch['list_id'].'" class="btn btn-success"><span class="glyphicon glyphicon-unchecked"></span></a>';
								}
							?>
							 <a title="Delete Task" href="delete_query.php?list_id=<?php echo $fetch['list_id']?>" class="btn btn-danger"><span class="glyphicon glyphicon-remove"></span></a>
					</td>
				</tr>
				<?php
					}
				?>
			</tbody>
		</table>
	</div>
</body>
</html>