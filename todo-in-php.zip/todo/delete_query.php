<?php
	require_once 'dbconnect.php';
	
	if($_GET['list_id']){
		$list_id = $_GET['list_id'];
		
		$conn->query("DELETE FROM `todo_list` WHERE `list_id` = $list_id") or die(mysqli_errno());
		header("location: index.php");
	}	
?>