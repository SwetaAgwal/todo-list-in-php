<?php
	require_once 'dbconnect.php';
	if(ISSET($_POST['add'])){
		if($_POST['list'] != ""){
			$list = $_POST['list'];
			
			$conn->query("INSERT INTO `todo_list` VALUES('', '$list', '0')");
			header('location:index.php');
		}
	}
?>