<?php
	require_once 'dbconnect.php';
	
	if($_GET['list_id'] != ""){
		$list_id = $_GET['list_id'];
		$query = $conn->query("SELECT * FROM `todo_list` WHERE `list_id` = $list_id");
		$fetch = $query->fetch_array();
		if($fetch['status'] != "1"){
			$conn->query("UPDATE `todo_list` SET `status` = '1' WHERE `list_id` = $list_id") or die(mysqli_errno());
		}
		else {
			$conn->query("UPDATE `todo_list` SET `status` = '0' WHERE `list_id` = $list_id") or die(mysqli_errno());
		}
		header('location: index.php');
	}
?>